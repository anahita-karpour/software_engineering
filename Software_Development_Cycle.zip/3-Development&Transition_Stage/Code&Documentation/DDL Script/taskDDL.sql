CREATE TABLE task(
taskNumber INTEGER PRIMARY KEY AUTOINCREMENT,
taskName TEXT(20) NOT NULL,
taskDetail TEXT(100),
taskDueDate TEXT NOT NULL
);

INSERT INTO task VALUES(1, "TaskOne", "some extra info", "2022-06-22");
INSERT INTO task VALUES(2, "TaskTwo", "some extra info", "2022-06-24");
INSERT INTO task VALUES(3, "TaskThree", "some extra info", "2022-06-23");
INSERT INTO task VALUES(4, "TaskFour", "some extra info", "2022-06-28");