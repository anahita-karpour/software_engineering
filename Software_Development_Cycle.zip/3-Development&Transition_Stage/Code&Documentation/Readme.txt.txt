Assumption made in the software development: 
	Task name and task due date were assumed could not be null whereas task details was assumed could be null.

Note:
In developer testing, traceability matrix and acceptance test folders additional excel documents are provided for viewing ease. The excels contain the same information as the word documents in those folders.
In folders: UI Wireframe, Design diagram; images are also provided for viewing ease.
DDL Script folder contains the sql script.