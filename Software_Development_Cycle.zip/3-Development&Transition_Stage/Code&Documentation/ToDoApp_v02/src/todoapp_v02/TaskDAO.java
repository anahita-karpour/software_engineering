/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import java.util.ArrayList;

/**
 * Data Access Object (DAO) Interface for Task
 * @author Anahita Karpour
 */
public interface TaskDAO {
    /**
     * Public method of the interface TaskDAO for adding a task to the database
     * @param task the task to add to the database
     * @return a boolean value 
     */
    public boolean addTask(Task task);
    /**
     * Public method of the interface TaskDAO for deleting a task from the database
     * @param task the task to delete from the database
     * @return a boolean value
     */
    public boolean deleteTask(Task task);
    /**
     * Public method of the interface TaskDAO for getting the information on a selected task
     * @param number the task number of the desired task to be retrieved
     * @return the requested Task
     */
    public Task getSelectedTask(String number);
    /**
     * Public method of the interface TaskDAO for obtaining all the tasks from the database
     * @return an arraylist of all tasks in the database
     */
    public ArrayList<Task> getTaskList();
    /**
     * Public method of the interface TaskDAO for obtaining all the tasks within seven days from the input string date
     * @param dateStr string date in the format of yyyy-MM-dd
     * @return an arraylist of tasks within the week of the input date.
     */
    public ArrayList<Task> getTasksInAWeek(String dateStr);
    /**
     * Public method of the interface TaskDAO for updating the selected task information.
     * @param task Task details to be updated
     * @return a boolean value
     */
    public boolean modifyTask(Task task);
}
