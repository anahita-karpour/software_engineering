/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.text.ParseException;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import static todoapp_v02.ToDoTaskUI.jTblTasksList;

/**
 * The ToDoTaskUI class implements TableModelListener and opens a new JFrame
 * window that displays all the tasks names and numbers from the Task table of
 * the database
 *
 * @author Anahita Karpour
 */
public class ToDoTaskUI extends javax.swing.JFrame implements TableModelListener {

    /**
     * Static variable of type DefaultTableModel holds the table model of
     * ToDoTaskUI class
     */
    public static DefaultTableModel tasksModel;
    /**
     * class variable of type ListSelectionModel that holds the ToDoTaskUI
     * ListSelectionModel selection
     */
    public ListSelectionModel lstModel;
    /**
     * An object of the TaskDaoImp class
     */
    public TaskDaoImp dao;

    /**
     * Static variable that holds the selected task number
     */
    public static int selectedTaskNumber;
    /**
     * A static variable of class TaskDetailsUI
     */
    public static TaskDetailsUI taskDetailUI;
    /**
     * static boolean variable is set to true when task details 
     */
    public static boolean detailUIIsOpen;
    /**
     * static boolean variable is set to true when weeklyUI is open
     */
    public static boolean weeklyUIIsOpen;
    /**
     * static boolean variable is set to true when taskDetails window is opened after weekly report
     */
    public static boolean wToDIsOpen;
    /**
     * static boolean variable is set to true when add window is opened
     */
    public static boolean addIsOpen;
    /**
     * A static variable of class addTask
     */
    public static AddANewTaskUI addTask;
    
    //public static boolean detailUIIsOpen, weeklyUIIsOpen, wToDIsOpen, addIsOpen;

    /**
     * Constructor of the ToDoTaskUI. It creates a new form ToDoTaskUI.
     */
    public ToDoTaskUI() {
        initComponents();
        lstModel = null;
        setResizable(false);

        //fill an arraylist with the lists of tasks from the database
        try {
            dao = new TaskDaoImp();
            ArrayList<Task> tasks;
            tasks = dao.getTaskList();

            tasksModel = (DefaultTableModel) jTblTasksList.getModel();

            Object rowData[] = new Object[5];
            for (int i = 0; i < (tasks.size()); i++) {
                rowData[0] = tasks.get(i).getTaskNumber();
                rowData[1] = tasks.get(i).getTaskName();
                rowData[2] = tasks.get(i).getTaskDueDate();
                rowData[3] = tasks.get(i).getTaskDetail();
                tasksModel.addRow(rowData);
            }

            designTable(lstModel, jScrollPane, jTblTasksList);
            //Add TableModelListener
            jTblTasksList.getModel().addTableModelListener(this);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "To Do Task window could not be displayed. Please try again and contact your system administrator if problem presists. " + e.getMessage(), "To Do Task Window Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }

    /**
     * Designs the tasks table on the To Do TaskUI with input selection option
     * and table, no table header and white background. Table has four columns
     * but the last two columns are hidden.
     *
     * @param lstM ListSelectionModel for the input table
     * @param jScroll JScrollPane component
     * @param jtable JTable component
     */
    private void designTable(ListSelectionModel lstM, JScrollPane jScroll, JTable jtable) {
        try {
            //Container Design
            getContentPane().setBackground(Color.WHITE);

            //Setting the table selection mode to single 
            lstM = jtable.getSelectionModel();
            lstM.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            //JScroll Design
            jScroll.getViewport().setBackground(Color.WHITE);

            //Table Design
            jtable.getTableHeader().setVisible(false);
            jtable.setRowHeight(25);
            //set columns max widths
            jtable.getColumnModel().getColumn(0).setMaxWidth(80);

            //Hide column third and fourth
            jtable.getColumnModel().getColumn(2).setMinWidth(0);
            jtable.getColumnModel().getColumn(2).setMaxWidth(0);
            jtable.getColumnModel().getColumn(2).setWidth(0);

            jtable.getColumnModel().getColumn(3).setMinWidth(0);
            jtable.getColumnModel().getColumn(3).setMaxWidth(0);
            jtable.getColumnModel().getColumn(3).setWidth(0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "To Do Task table could not be displayed. Please try again and contact your system administrator if problem presists." + e.getMessage(), "To Do Task Table Display Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addATaskBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jScrollPane = new javax.swing.JScrollPane();
        jTblTasksList = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("To Do Tasks");
        setBackground(new java.awt.Color(255, 255, 255));
        setName("ToDoTasksFrame"); // NOI18N

        addATaskBtn.setText("Add a New Task");
        addATaskBtn.setName("AddNewTask"); // NOI18N
        addATaskBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addATaskBtnActionPerformed(evt);
            }
        });

        deleteBtn.setIcon(new javax.swing.ImageIcon("D:\\Users\\7-Software Engineering\\Assessment 3\\ToDoApp_v02\\img\\Household-Waste-icon-16pixel.png")); // NOI18N
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        jScrollPane.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane.setName("jScroll"); // NOI18N

        jTblTasksList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Task Number", "Task Name", "Task Detail", "Task DueDate"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTblTasksList.setGridColor(new java.awt.Color(204, 204, 204));
        jTblTasksList.setIntercellSpacing(new java.awt.Dimension(0, 0));
        jTblTasksList.setName("ModelTbl"); // NOI18N
        jTblTasksList.setRowHeight(25);
        jTblTasksList.setSelectionBackground(new java.awt.Color(215, 215, 255));
        jTblTasksList.setShowGrid(false);
        jTblTasksList.setUpdateSelectionOnSort(false);
        jTblTasksList.setVerifyInputWhenFocusTarget(false);
        jTblTasksList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTblTasksListMouseClicked(evt);
            }
        });
        jScrollPane.setViewportView(jTblTasksList);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(addATaskBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 189, Short.MAX_VALUE)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(addATaskBtn)
                    .addComponent(deleteBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Opens a new AddANewTaskUI window for adding a new task name, task due
     * date and task details
     *
     * @param evt
     */
    private void addATaskBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addATaskBtnActionPerformed
        try {
            //if there is a TaskDetailUI window or weekly report window open close it
            if (ToDoTaskUI.detailUIIsOpen) {
                ToDoTaskUI.taskDetailUI.dispose();
            }
            if (ToDoTaskUI.weeklyUIIsOpen) {
                TaskDetailsUI.weeklyUI.dispose();
            }
            if (ToDoTaskUI.wToDIsOpen) {
                WeeklyCalenderUI.taskDetailsUI.dispose();
            }
            if (ToDoTaskUI.addIsOpen) {
                ToDoTaskUI.addTask.dispose();
            }         
            
            
            //Open a new Add task window
            addTask = new AddANewTaskUI();
            addTask.setVisible(true);
            addIsOpen = true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Add A New Task window could not be displayed. Please try again and contact your system administrator if problem presists." + e.getMessage(), "New Task Window Error", JOptionPane.INFORMATION_MESSAGE, null);
        }

    }//GEN-LAST:event_addATaskBtnActionPerformed

    /**
     * Converts an input from type String to type date with the format
     * 'yyyy-MM-dd' and sets the input DateChooser component
     *
     * @param dateStr input of type String
     * @param jDateChooser input date chooser component
     */
    private void setDateChooser(String dateStr, JDateChooser jDateChooser) {

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dateD = dateFormat.parse(dateStr);
            jDateChooser.setDate(dateD);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "String date could not be parsed. Please contact your system administrator if problem presists." + ex.getMessage(), "Date Parsing Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }

    /**
     * On double click event calls the goToTaskDetailsUI() method to open the Task
     * Details window for the selected task
     *
     * @param evt Mouse click event
     */
    private void jTblTasksListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTblTasksListMouseClicked
        try {
            //if a task is selected
            if (jTblTasksList.getSelectedRowCount() == 1) {
                //get the selected row
                int selectedRowIndex = jTblTasksList.getSelectedRow();

                //get the details of the task from the selected row
                String stTaskNumber = tasksModel.getValueAt(selectedRowIndex, 0).toString();
                String taskName, taskDetail;
                taskName = tasksModel.getValueAt(selectedRowIndex, 1).toString();
                String dateStr = tasksModel.getValueAt(selectedRowIndex, 2).toString();
                taskDetail = tasksModel.getValueAt(selectedRowIndex, 3).toString();

                //if the mouse has been clicked twice
                if (evt.getClickCount() == 2) {
                    //This method was added using refractoring.
                    goToTaskDetailsUI(stTaskNumber, taskName, dateStr, taskDetail);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a task from the list!", "Error", JOptionPane.INFORMATION_MESSAGE, null);
            }
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Task details could not be displayed! Please contact your system administrator if problem presists." + e.getMessage(), "Display Error", JOptionPane.INFORMATION_MESSAGE, null);

        }
    }//GEN-LAST:event_jTblTasksListMouseClicked

    /**
     * Opens a new TaskDetailsUI window and fills the TaskDetailsUI window
     * components with the selected task details.
     *
     * @param stTaskNumber selected task number
     * @param name selected task's name
     * @param date selected task due date
     * @param detail selected task details
     * @throws NumberFormatException
     */
    private void goToTaskDetailsUI(String stTaskNum, String name, String date, String detail) throws NumberFormatException {
        try {            
            //if there is a TaskDetailUI window or weekly report window open close it
            if (detailUIIsOpen) {
                taskDetailUI.dispose();
            }
            if (weeklyUIIsOpen) {
                TaskDetailsUI.weeklyUI.dispose();
            }
            if (wToDIsOpen) {
                WeeklyCalenderUI.taskDetailsUI.dispose();
            }
            if (addIsOpen) {
                addTask.dispose();
            }            
            
            //set the selected task number value
            selectedTaskNumber = Integer.parseInt(stTaskNum);

            //open a new TaskDetailsUI window
            taskDetailUI = new TaskDetailsUI();
            taskDetailUI.setVisible(true);
            detailUIIsOpen = true;
            System.out.println("detailUIIsOpen is open");
            taskDetailUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            //fill the new TaskDetailUI window components
            taskDetailUI.taskNameFld.setText(name);
            this.setDateChooser(date, taskDetailUI.dueDateChooser);
            taskDetailUI.taskDetailTxtPane.setText(detail);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Task details window could not be displayed! Please contact your system administrator if problem presists." + e.getMessage(), "Display Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }

    /**
     * Deletes the selected task from the database
     *
     * @param evt
     */
    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed

        try {
            //if there is a TaskDetailUI window or weekly report window open close it
            if (detailUIIsOpen) {
                taskDetailUI.dispose();
            }
            if (weeklyUIIsOpen) {
                TaskDetailsUI.weeklyUI.dispose();
            }
            if (wToDIsOpen) {
                WeeklyCalenderUI.taskDetailsUI.dispose();
            }
            if (addIsOpen) {
                addTask.dispose();
            }
            
            
            //if a task is selected
            if (jTblTasksList.getSelectedRowCount() == 1) {
                //get the selected row
                int selectedRowIndex = jTblTasksList.getSelectedRow();
                String selectedRowStr = tasksModel.getValueAt(selectedRowIndex, 0).toString();

                //Get confirmation from the user before deleting
                int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this task?", "Delete?", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    TaskDaoImp dao = new TaskDaoImp();
                    Task selectedTask = dao.getSelectedTask(selectedRowStr);
                    
                    //if delete was successful
                    if (dao.deleteTask(selectedTask) == true) {
                        ToDoTaskUI.tasksModel.fireTableDataChanged();
                        JOptionPane.showMessageDialog(this, "Task was deleted successfully.", "Successful", JOptionPane.INFORMATION_MESSAGE, null);

                    } else {
                        JOptionPane.showMessageDialog(this, "Task could not be deleted!", "Error", JOptionPane.INFORMATION_MESSAGE, null);
                    }
                } else if (response == JOptionPane.NO_OPTION) {
                    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a task from the list!", "Selection Error", JOptionPane.INFORMATION_MESSAGE, null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Task could not be deleted! Please contact your system administrator if problem presists." + e.getMessage(), "Delete Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    /**
     * The main method of class ToDoTaskUI. It creates a new ToDoTaskUI frame and sets it to visible.
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ToDoTaskUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ToDoTaskUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ToDoTaskUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ToDoTaskUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ToDoTaskUI().setVisible(true);
            }
        });
    }

    /**
     * ToDoTaskUI class GUI variables
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addATaskBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JScrollPane jScrollPane;
    public static javax.swing.JTable jTblTasksList;
    // End of variables declaration//GEN-END:variables

    /**
     * This method overrides the tableChanged method of TableModelListener. It
     * tells the listener: ToDoTaskUI that the table model has changed. On
     * table changed event it clears the tasks table, refill the tasks arraylist
     * and refills the tasks table.
     *
     * @param e a TableModelEvent to notify listener that a table model has
     * changed
     */
    @Override
    public void tableChanged(TableModelEvent e) {

        if (TableModelEvent.UPDATE == e.getType()) {

            //Refill the data
            ArrayList<Task> tasks;
            tasks = dao.getTaskList();

            tasksModel = (DefaultTableModel) jTblTasksList.getModel();
            //clear the table
            tasksModel.setRowCount(0);
            Object rowData[] = new Object[5];
            for (int i = 0; i < (tasks.size()); i++) {
                rowData[0] = tasks.get(i).getTaskNumber();
                rowData[1] = tasks.get(i).getTaskName();
                rowData[2] = tasks.get(i).getTaskDueDate();
                rowData[3] = tasks.get(i).getTaskDetail();
                tasksModel.addRow(rowData);
            }
        }
    }
}
