/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A solid class that provides implementation for the abstract TaskDao class.
 *
 * @author Anahita Karpour
 */
public class TaskDaoImp implements TaskDAO {

    /**
     * Constructor for class TaskDaoImp
     */
    public TaskDaoImp() {
    }

    /**
     * Inserts a task into the database
     *
     * @param task the desired task to be added
     * @return true if successful and false if unsuccessful
     */
    @Override
    public boolean addTask(Task task) {
        String sql = "INSERT INTO task(taskName,taskDetail, taskDueDate) VALUES(?, ?, ?)";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DbConnection.connect();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, task.getTaskName());
            preparedStatement.setString(2, task.getTaskDetail());
            String dueDate = task.getTaskDueDate();
            preparedStatement.setString(3, dueDate);
            preparedStatement.executeUpdate();
            
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode() + ": " + ex.getMessage() + ". Please contact the system administrator.");
            return false;
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }

    /**
     * Deletes a task with the desired task number from the database
     *
     * @param task the desired task to be deleted
     * @return true if it successful to delete the task and false if it is
     * unsuccessful
     */
    @Override
    public boolean deleteTask(Task task) {
        String sql = "DELETE FROM task WHERE taskNumber=?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DbConnection.connect();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, task.getTaskNumber());
            preparedStatement.executeUpdate();

            return true;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode() + ": " + ex.getMessage() + ". Please contact the system administrator.");
            return false;
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }

    /**
     * Gets the task with the desired task number from the database
     *
     * @param number task number of the desired task
     * @return the task with the desired task number
     */
    @Override
    public Task getSelectedTask(String number) {
        String sql = "SELECT * FROM task WHERE taskNumber = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DbConnection.connect();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, number);
            resultSet = preparedStatement.executeQuery();
            System.out.println("taskNumber  taskName    taskDetail                  taskDueDate");

            //loop through the result set using the next() method of the ResultSet instance
            if (resultSet.next()) {
                //Get the data in each iteration using the getInt() and getString() methods of the 
                //ResultSet instance.
                int taskNumber = resultSet.getInt("taskNumber");
                String taskName = resultSet.getString("taskName");
                String taskDetail = resultSet.getString("taskDetail");
                String taskDueDate = resultSet.getString("taskDueDate");
                Date dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(taskDueDate);
                Task task = new Task(taskNumber, taskName, taskDetail, taskDueDate);

                System.out.println(taskNumber + "\t"
                        + taskName + "\t"
                        + taskDetail + "\t"
                        + taskDueDate);
                return task;
            } else {
                return null;
            }

        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
            return null;
        } catch (ParseException ex) {
            System.out.println(ex.getCause() + ": " + ex.getMessage() + ". Please contact your system administrator.");
            return null;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }

    /**
     * Select all rows in the task table of the database
     *
     * @return a list of tasks in the database
     */
    @Override
    public ArrayList<Task> getTaskList() {

        String sql = "SELECT * FROM task ORDER BY taskDueDate";
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            ArrayList<Task> tasks = new ArrayList<>();
            connection = DbConnection.connect();
            //An instance of the Statement class from the Connection object
            statement = connection.createStatement();
            // An instance of the ResultSet class by calling the executeQuery method of the statement object.
            // The executeQuery method accepts a sql select statement.
            resultSet = statement.executeQuery(sql);
            System.out.println("taskNumber  taskName    taskDetail                  taskDueDate");

           //loop through the result set using the next() method of the ResultSet instance
            while (resultSet.next()) {
                //Get the data in each iteration using the getInt() and getString() methods of the 
                //ResultSet instance.
                int taskNumber = resultSet.getInt("taskNumber");
                String taskName = resultSet.getString("taskName");
                String taskDetail = resultSet.getString("taskDetail");
                String taskDueDate = resultSet.getString("taskDueDate");

                Date dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(taskDueDate);
                Task task = new Task(taskNumber, taskName, taskDetail, taskDueDate);

                tasks.add(task);

                System.out.println(taskNumber + "\t"
                        + taskName + "\t"
                        + taskDetail + "\t"
                        + taskDueDate);

            }
            return tasks;
        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
            return null;
        } catch (ParseException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }

    /**
     * Gets a list of all tasks in a week starting from the input date
     *
     * @param dateStr date in String and format of yyyy-MM-dd
     * @return a list of tasks within seven days from the input date
     */
    @Override
    public ArrayList<Task> getTasksInAWeek(String dateStr) {

        String sql = "SELECT * FROM task WHERE taskDueDate < date(?, '+7 day') AND taskDueDate >= date(?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        //An instance of the Connection class to connect to the SQLit database
        try {
            ArrayList<Task> tasks = new ArrayList<>();
            connection = DbConnection.connect();
            //connection = DriverManager.getConnection(sql);
            //An instance of the Statement class from the Connection object
            preparedStatement = connection.prepareStatement(sql);

            //An instance of the ResultSet class by calling the executeQuery method of the statement object.
            //The executeQuery method accepts a sql select statement.
            preparedStatement.setString(1, dateStr);
            preparedStatement.setString(2, dateStr);
            System.out.println("Date to string: " + dateStr);

            resultSet = preparedStatement.executeQuery();

            System.out.println("taskNumber  taskName    taskDetail                  taskDueDate");

            // loop through the result set using the next() method of the ResultSet instance
            while (resultSet.next()) {
                //Get the data in each iteration using the getInt() and getString() methods of the 
                //ResultSet instance.
                int taskNumber = resultSet.getInt("taskNumber");
                String taskName = resultSet.getString("taskName");
                String taskDetail = resultSet.getString("taskDetail");
                String taskDueDate = resultSet.getString("taskDueDate");

                Date dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(taskDueDate);
                Task task = new Task(taskNumber, taskName, taskDetail, taskDueDate);
                tasks.add(task);

                System.out.println(taskNumber + "\t"
                        + taskName + "\t"
                        + taskDetail + "\t"
                        + taskDueDate);

            }
            return tasks;
        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
            return null;
        } catch (ParseException ex) {
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }

    /**
     * Modifies a task with the updated details. The search and modification is
     * done based on the task number.
     *
     * @param task with the modified details
     * @return true if the update was successful and false if the update was
     * unsuccessful
     */
    @Override
    public boolean modifyTask(Task task) {

        String sql = "UPDATE task SET "
                + "taskName = ?, "
                + "taskDetail = ?, "
                + "taskDueDate = ?"
                + "WHERE TaskNumber = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DbConnection.connect();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, task.getTaskName());
            preparedStatement.setString(2, task.getTaskDetail());
            preparedStatement.setString(3, task.getTaskDueDate());
            preparedStatement.setInt(4, task.getTaskNumber());

            preparedStatement.executeUpdate();

            return true;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode() + ": " + ex.getMessage() + ". Please contact the system administrator.");
            return false;
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println(e.getErrorCode() + ": " + e.getMessage() + ". Please contact the system administrator.");
                }
            }
        }
    }
}
