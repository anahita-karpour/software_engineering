/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import javax.swing.JFrame;

/**
 * The ToDoApp main class creates and opens a new ToDoTaskUI
 * @author Anahita Karpour
 */
public class ToDoApp_v02 {
    
    /**
     * Constructor of class ToDoApp_v02
     */
    public ToDoApp_v02(){}

    /**
     * The main class of the ToDoApp software program opens a new ToDoTaskUI window.
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                
        try{
            JFrame frame = new ToDoTaskUI();
            frame.setVisible(true);      
        } catch(Exception e){
            System.out.println("ToDoTaskUI could not be displayed. Error: " + e.getCause().toString());
        }
    }    
}
