/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Provides connection to the database
 *
 * @author Anahita Karpour
 */
public class DbConnection {

    /**
     * Constructor for the class DbConnection
     */
    public DbConnection() {
    }

    /**
     * Connect to the ToDo_v02.db database
     *
     * @return the Connection object
     */
    public static Connection connect() {

        Connection conn = null;
        try {
            //SQLite connection string
            //This is where my ToDo database is located on my computer: D:/Users/7-Software Enginerring
            String databaseLocation = "D:/Users/7-Software Engineering/Assessment 3/db/todo_v02.db";
            // db parameters
            String url = "jdbc:sqlite:" + databaseLocation;
            // creating a database connection
            conn = DriverManager.getConnection(url);
            //succerssful message
            System.out.println("Connection to the database has successfully been established.");

        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + ": Connection to the database has failed (" + e.getMessage() + "). Please contact the system administrator.");
        }
        return conn;
    }
}
