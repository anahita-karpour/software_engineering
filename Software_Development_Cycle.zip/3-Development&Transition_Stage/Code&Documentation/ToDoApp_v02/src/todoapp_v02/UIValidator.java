/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.text.JTextComponent;

/**
 * This class validates input data from the UI before processing and storing them in the database.
 * @author Anahita Karpour
 */
public class UIValidator {
    
    /**
     * Constructor for the class UIValidator
     */
    public UIValidator(){}
    
    /**
     * Checks to ensure there is an input present in a component of type JTextComponent.
     * @param c a type JTextComponent
     * @param title JTextComponent name
     * @return true if there is an input of length greater than zero is present in the component otherwise returns false
     */  
    public static boolean isPresent(JTextComponent c, String title){
        
        if(c.getText().length() == 0){
            JOptionPane.showMessageDialog(c, title + " is a required field. Please try again.", "Invalid Entry", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    /**
     * Checks to ensure the entered text is alphanumeric and between one to 20 character long, no white space is allowed at the start or end
     * and no special characters are allowed as well.
     * @param c a type JTextComponent
     * @param title JTextComponent name
     * @return true if the input text is alphanumeric of between 1 to 20 character long (white space is allowed in between), no white space allowed at the start or end otherwise returns false
    */
    public static boolean isNameValid(JTextComponent c, String title){
        
        String pattern = "^(?=.{1,20}$)[a-zA-Z0-9][a-zA-Z0-9_\\s-]*[a-zA-Z0-9]$";
        if (!c.getText().matches(pattern)){
            JOptionPane.showMessageDialog(c, title + " must be between one to twenty alphanumeric character long.", "Invalid Entry", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
        
    }
    
    /**
     * Check to ensure the entered text is is alphanumeric and between one to 100 character long, white spaces is not allowed at the start or end.
     * @param c a type JTextComponent 
     * @param title JTextComponent name
     * @return true if the input text is alphanumeric of between 1 to 100 character long (white space is allowed) otherwise returns false
     */
    public static boolean isDetailValid(JTextComponent c, String title){
        
        String pattern = "^(?=.{1,100}$)[a-zA-Z0-9][a-zA-Z0-9_\\s-]*[a-zA-Z0-9]$"; 
        
        if(c.getText().length() > 0){
            if (!c.getText().matches(pattern)){
                JOptionPane.showMessageDialog(c, title + " must be between one to hundred alphanumeric character long.", "Invalid Entry", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return true;
    }
    
    /** 
     * Checks to see if a date is selected from the date chooser component
     * @param d a type JDateChooser
     * @param title DateChooser name
     * @return true if a date has been selected from the JDateChooser component otherwise returns false
    */ 
    public static boolean isDateValid(JDateChooser d, String title){
        if(d.getDate() == null){
            JOptionPane.showMessageDialog(d, title + " is a required field. Please choose a date.", "Null Entry", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}
