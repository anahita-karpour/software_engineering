/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

/**
 * Task class represents the concept Task 
 * @author Anahita Karpour
 */
public class Task {
    //variables
    /**
     * Private class variable of type integer that holds the task number.
     */
    private int taskNumber;
    /**
     * Private class variable of type String that holds the task name 
     */
    private String taskName;
    /**
     * Private class variable of type String that holds the task detail
     */
    private String taskDetail;
    /**
     * Private class variable of type String that holds the task due date
     */
    private String taskDueDate;
    
    /**
     * constructor of class Task
     */
    public Task(){
        taskNumber = 0;
        taskName = "";
        taskDetail = "";
        taskDueDate = null;
    }
    /** 
     * constructor of class Task
     * @param taskNumberValue task number
     * @param taskNameValue name/title of the task
     * @param taskDueDateValue  due date of the task
     */
    public Task(int taskNumberValue, String taskNameValue, String taskDueDateValue){
        taskNumber = taskNumberValue;
        taskName = taskNameValue;
        taskDueDate = taskDueDateValue;
    }
    
    /**
     * Constructor of class Task
     * @param taskNumberValue task number
     * @param taskNameValue name/title of the task
     * @param taskDetailValue task details
     * @param taskDueDateValue  task due date
     */
    public Task(int taskNumberValue, String taskNameValue, String taskDetailValue, String taskDueDateValue){
        taskNumber = taskNumberValue;
        taskName = taskNameValue;        
        taskDetail = taskDetailValue;
        taskDueDate = taskDueDateValue;
    }
    /**
     * Constructor of class Task
     * @param taskNameValue task name/title of the task
     * @param taskDetailValue task details 
     * @param taskDueDateValue task due date
     */
    public Task(String taskNameValue, String taskDetailValue, String taskDueDateValue){
        
        taskName = taskNameValue;        
        taskDetail = taskDetailValue;
        taskDueDate = taskDueDateValue;
    }
    /**
     * The getter method for taskNumber variable of class task.
     * @return the task number value of the task
     */
    public int getTaskNumber(){
        return taskNumber;
    }
    /**
     * The getter method for taskName variable of class task.
     * @return task name value of the task
     */
    public String getTaskName(){
        return taskName;
    }
    /**
     * The setter method for taskName variable of class task.
     * @param taskName task name in string for the task
     */
    public void setTaskName(String taskName){
        this.taskName = taskName;
    }
    
    /**
     * The getter method for taskDetail variable of class task.
     * @return task details of the task
     */
    public String getTaskDetail(){
        return taskDetail;
    }
    /**
     * The setter method for taskDetail variable of class task.
     * @param taskDetail task details in string for the task
     */
    public void setTaskDetail(String taskDetail){
        this.taskDetail = taskDetail;
    }    
    
    /**
     * The getter method for taskDueDate variable of class task.
     * @return task due date in string
     */
    public String getTaskDueDate(){
        return taskDueDate;
    }
    /**
     * The setter method for taskDueDate variable of class task.
     * @param taskDueDate task due date in string for the task
     */
    public void setTaskDueDate(String taskDueDate){
        this.taskDueDate = taskDueDate;
    }
}
