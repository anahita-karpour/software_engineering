/*
 * Anahita Karpour - 5012566
 * Assignment Three
 * BIT707 Software Engineering
 */
package todoapp_v02;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * WeeklyCalenderUI creates a calender report for the selected task.
 *
 * @author Anahita Karpour
 */
public class WeeklyCalenderUI extends javax.swing.JFrame {

    /**
     * Static variable of type DefaultTableModel that holds the table model
     */
    public static DefaultTableModel weeklyModel;

    /**
     * class variable of type ListSelectionModel holds ListSelectionModel
     * selection
     */
    public ListSelectionModel lstModel;
    /**
     * An object of the TaskDaoImp class
     */
    public TaskDaoImp dao;

    /**
     * Static arraylist variable of type String that holds the list of days for
     * a specific task weekly calender report
     */
    public static ArrayList<String> days;
    /**
     * Static arraryList variable of type String that holds the list of dates
     * for a specific task weekly calender report
     */
    public static ArrayList<String> dates;
    /**
     * A static variable of String that holds the selected task number
     */
    public static String selectedtaskStr;
    /**
     * Static variable of type TaskDetailsUI
     */
    public static TaskDetailsUI taskDetailsUI;

    /**
     * Static variable of type WeeklyCalenderUI
     */
    public static WeeklyCalenderUI weeklyCalender;

    /**
     * Creates new form WeeklyCalenderUI
     */
    public WeeklyCalenderUI() {
        initComponents();

        try {
            lstModel = null;
            dao = new TaskDaoImp();
            ArrayList<Task> tasks;

            //fill an arraylist with the lists of tasks from the database
            tasks = dao.getTaskList();

            //set Background as white
            this.getContentPane().setBackground(Color.WHITE);
            jScrollPane1.setBackground(Color.WHITE);
            jTable1.setBackground(Color.WHITE);
            jScrollPane1.getViewport().setBackground(Color.WHITE);
            setResizable(false);

            this.setTitle("Weekly Calender");
            weeklyModel = (DefaultTableModel) jTable1.getModel();

            //set the selection model to single
            ListSelectionModel lstModel;
            lstModel = jTable1.getSelectionModel();
            lstModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            //set to can't be edited
            jTable1.setDefaultEditor(Object.class, null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "To Do Task window could not be displayed. Please try again and contact your system administrator if problem presists." + e.getMessage(), "To Do Task Window Error", JOptionPane.INFORMATION_MESSAGE, null);
        }

        //Call to the displayWeeklyReport method
        displayWeeklyReport();
    }

    /**
     * Displays the table of tasks for the week starting from the due day of the
     * selected task
     *
     * @throws HeadlessException
     */
    private void displayWeeklyReport() throws HeadlessException {
        //Print the table of tasks for the week starting from the due day of the selected task
        try {
            String dueTaskStr = dao.getSelectedTask(TaskDetailsUI.selectedtaskStr).getTaskDueDate();
            Task selectedTask = dao.getSelectedTask(TaskDetailsUI.selectedtaskStr);
            ArrayList<Task> weeklyTasks;
            weeklyTasks = dao.getTasksInAWeek(dueTaskStr);
            String startDateStr = selectedTask.getTaskDueDate();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date dateTask;
            String day = "";
            DateFormat dayformatter = new SimpleDateFormat("EEEE");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dueDate = "";
            int daysNumber = 7;
            days = new ArrayList<>();
            dates = new ArrayList<>();

            //set columns max widths
            jTable1.getColumnModel().getColumn(0).setMaxWidth(80);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(75);

            //fill the arraylists of days and dates
            for (int i = 0; i < daysNumber; i++) {
                Calendar calender = Calendar.getInstance();
                try {
                    calender.setTime(formatter.parse(startDateStr));

                } catch (ParseException ex) {
                    Logger.getLogger(TaskDetailsUI.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {
                    dateTask = dateFormat.parse(startDateStr);
                    day = dayformatter.format(dateTask);

                } catch (ParseException ex) {
                    Logger.getLogger(TaskDetailsUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                dates.add(startDateStr);
                // number of days to add
                calender.add(Calendar.DATE, 1);
                // nextDay is now the new date
                startDateStr = formatter.format(calender.getTime());
                days.add(day);
            }
            for (String tday : days) {
                System.out.println(tday);
            }
            for (String tdate : dates) {
                System.out.println(tdate);
            }

            //print the days of the week for the selected task and those tasks with similar due dates
            for (int i = 0; i < days.size(); i++) {
                weeklyModel.addRow(new Object[]{
                    days.get(i), dates.get(i), ""
                });
                int counter = 0;
                for (int j = 0; j < weeklyTasks.size(); j++) {
                    dueDate = weeklyTasks.get(j).getTaskDueDate();

                    String taskDay = "";
                    try {
                        taskDay = dayformatter.format(dateFormat.parse(weeklyTasks.get(j).getTaskDueDate()));
                    } catch (ParseException ex) {
                        Logger.getLogger(WeeklyCalenderUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (taskDay.equals(days.get(i))) {
                        counter = counter + 1;
                        if (counter > 1) {
                            weeklyModel.addRow(new Object[]{
                                "", "", weeklyTasks.get(j).getTaskName(), weeklyTasks.get(j).getTaskNumber()
                            });
                        }
                    }
                }
            }

            //print those tasks that do not have the same due date
            for (int k = 0; k < weeklyModel.getRowCount(); k++) {
                int counter3 = 0;
                for (int i = 0; i < weeklyTasks.size(); i++) {

                    dueDate = weeklyTasks.get(i).getTaskDueDate();

                    String taskDay = "";
                    try {
                        taskDay = dayformatter.format(dateFormat.parse(weeklyTasks.get(i).getTaskDueDate()));
                    } catch (ParseException ex) {
                        Logger.getLogger(WeeklyCalenderUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (weeklyModel.getValueAt(k, 0).equals(taskDay)) {
                        counter3 = counter3 + 1;
                        if (counter3 == 1) {
                            weeklyModel.setValueAt(weeklyTasks.get(i).getTaskDueDate(), k, 1);
                            weeklyModel.setValueAt(weeklyTasks.get(i).getTaskName(), k, 2);
                            weeklyModel.setValueAt(weeklyTasks.get(i).getTaskNumber(), k, 3);
                        }
                    }
                }
                //Hide column third column
                jTable1.getColumnModel().getColumn(3).setMinWidth(0);
                jTable1.getColumnModel().getColumn(3).setMaxWidth(0);
                jTable1.getColumnModel().getColumn(3).setWidth(0);
            }
            //set the boolean variable weekly ui is open
            ToDoTaskUI.weeklyUIIsOpen = true;
            if (ToDoTaskUI.addIsOpen) {
                ToDoTaskUI.addTask.dispose();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(jTable1, "Weekly calender report could not be displayed. Please contact your system administrator if problem presist.", "Weekly Report Display Error", JOptionPane.INFORMATION_MESSAGE, null);

        }
    }

    /**
     * Takes the user from Weekly Calender window back to Task DetailsUI. It
     * opens a new instance of Task Details UI and displays the selected task on
     * the weekly report in the new TaskDetails UI.
     *
     * @param jTable JTable in the weekly calender report
     */
    private void goToDetailUI(JTable jTable) {
        try {
            //taskDetailsUI
            taskDetailsUI = new TaskDetailsUI();
            taskDetailsUI.setVisible(true);
            int i = jTable.getSelectedRow();
            //get the selected row
            System.out.println("Selected Index is: " + i);
            TaskDetailsUI.selectedtaskStr = jTable.getValueAt(i, 3).toString();
            System.out.println("Selected Task String is: " + selectedtaskStr);

            Task selectedTask = dao.getSelectedTask(selectedtaskStr);
            taskDetailsUI.taskNameFld.setText(selectedTask.getTaskName());
            taskDetailsUI.taskDetailTxtPane.setText(selectedTask.getTaskDetail());
            String dueDateStr = selectedTask.getTaskDueDate();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

            try {
                taskDetailsUI.dueDateChooser.setDate(formatter.parse(dueDateStr));

            } catch (ParseException ex) {
                Logger.getLogger(TaskDetailsUI.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            ToDoTaskUI.wToDIsOpen = true;
            System.out.println("wToDIsOpen");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Task Details UI could not be displayed. Please contact your system administrator if problem presists." + e.getMessage(), "Task Details from Weekly Report Error", JOptionPane.INFORMATION_MESSAGE, null);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("jframe"); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Day", "Date", "Task Name", "Task Number"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 354, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * On double clicking on weekly task table it calls the method goToDetailsUI()
     * to open the Task Details window for the selected task
     * @param evt: mouse click event 
     */
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (evt.getClickCount() == 2) {
            try {
                //set the boolean variable weekly ui is open
                ToDoTaskUI.weeklyUIIsOpen = false;
                if (ToDoTaskUI.detailUIIsOpen) {
                    ToDoTaskUI.taskDetailUI.dispose();
                }

                selectedtaskStr = jTable1.getValueAt(jTable1.getSelectedRow(), 3).toString();
                goToDetailUI(jTable1);
                setVisible(false);
                dispose();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(jTable1, "Please select a task name from the list!", "Selection Error", JOptionPane.INFORMATION_MESSAGE, null);
            }
        }
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * Main method of class WeeklyCalenderUI. It creates a new WeeklyCalenderUI
     * frame and sets it to visible
     *
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WeeklyCalenderUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WeeklyCalenderUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WeeklyCalenderUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WeeklyCalenderUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WeeklyCalenderUI().setVisible(true);
            }
        });
    }
    /**
     * GUI variables of class WeeklyCalenderUI
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}
