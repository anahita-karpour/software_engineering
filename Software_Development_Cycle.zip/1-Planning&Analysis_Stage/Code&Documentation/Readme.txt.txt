-> In order to depict the real life file management of the software project engineering each Word document has been placed in the respective folder.
-> Task One - Located in the Project Charter folder
-> Task Two - Located in the Quality Plan folder
-> Task Three - Located in the Requirmenets Analysis
-> Task Four - The source file located in the ToDoApp-v01 folder
		   The database of the source file in the db folder
		   The documentation in the Iteration 1 folder