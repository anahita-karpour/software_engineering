/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package todoapp_v01;

/**
 *
 * @author Anahita Karpour
 * The base code for connecting the To Do Java app to the Sqlite database was adapted from the SQLite tutorial at sqlitetutorials.net (SQLite Tutorial, n.d.).
 */
public class ToDoApp_v01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Print table Task of database ToDo.db
        System.out.println("Table 'Task' of Database 'ToDo.db'");
        System.out.println("taskNumber  taskName");
        DbConnection db = new DbConnection();
        db.selectAll();
    }
    
}
