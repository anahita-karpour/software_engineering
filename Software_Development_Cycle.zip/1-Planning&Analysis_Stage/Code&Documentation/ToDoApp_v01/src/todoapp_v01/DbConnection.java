/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todoapp_v01;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Anahita Karpour
 */
public class DbConnection {
    /**
     * Connect to the ToDo.db database
     * @return the Connection object
     */
    private Connection connect() {
        //SQLite connection string
        //This is where my ToDo database is located on my computer: D:/Users/7-Software Enginerring
        String databaseLocation = "D:/Users/7-Software Engineering/Assessment 1/db/ToDo.db";
        String url = "jdbc:sqlite:" + databaseLocation;
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(url);
        } catch(SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
    
    /**
     * Select all rows in the task table
     */
    public void selectAll(){
        String sql = "SELECT * FROM task";
        
        //An instance of the Connection class to connect to the SQLit database
        try(Connection conn = this.connect();
            //An instance of the Statement class from the Connection object
            Statement stmt = conn.createStatement();
            //An instance of the ResultSet class by calling the executeQuery method of the statement object.
            //The executeQuery method accepts a sql select statement.
            ResultSet rs = stmt.executeQuery(sql)){
        
            // loop through the result set using the next() method of the ResultSet instance
            while (rs.next()){
                //Get the data in each iteration using the getInt() and getString() methods of the 
                //ResultSet instance.
                System.out.println(rs.getInt("taskNumber") + "\t" +
                rs.getString("taskName") + "\t");
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
