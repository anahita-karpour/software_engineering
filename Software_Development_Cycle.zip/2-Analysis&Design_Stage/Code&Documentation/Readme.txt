Please refer to the following folders for the respective assignment section:

Task 1a- Acceptance Test Plans: Folder 'Acceptance Test Plans'
Task 1b- Traceability Matrix: Folder 'Traceability Matrix'
Task 2a & b- Class Diagram and ERD: Folder 'Class Diagram and ERD'
Task 3- UI Wireframe: Folder 'UI Wireframe'
Task 4- Analysis: in the word document 'BIT707_A2_5012566_AnahitaKarpour.doc'